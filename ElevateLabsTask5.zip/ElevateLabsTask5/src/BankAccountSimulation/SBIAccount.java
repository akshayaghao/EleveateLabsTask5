package BankAccountSimulation;

import java.util.ArrayList;
import java.util.List;

public class SBIAccount {
	
	private String AccountHolder;
	private double Balance;
    private List<String> TransactionHistory;
    
    public SBIAccount(String AccountHolder,double InitialBalance) {
    this.AccountHolder = AccountHolder;
    this.Balance=Balance;
    this.TransactionHistory= new ArrayList<>();
    TransactionHistory.add("Account Created For"+AccountHolder + "With Initial Balance ₹" + InitialBalance);
    
    
    	
    }
    
    
    public void Deposit(double amount) {
    	if (amount>0) {
    	Balance +=amount;
 TransactionHistory.add("Deposited"+ amount +"|Balance :₹" +Balance);
 System.out.println("Amount Deposited SuccessFully ₹ "+amount);
    	
    	}else {
    		System.out.println("Deposit Amount Must Be Greater Than 0.");
    		
			
		}
			
		}
    
    
    
    public void Withdraw(double amount) {
    	if (amount>0) {
    	if(amount<=Balance) {
    	Balance -=amount;
 TransactionHistory.add("Withdraw"+ amount +"|Balance :₹" +Balance);
 System.out.println("Amount Withdraw SuccessFully ₹ "+amount);
    	
    	}else {
    		System.out.println("Insufficient Balance In Your Account.");
    		
			
		}
    	
    	}else {
    		System.out.println("Withdraw Anount Must Be Greater Than 0.");
    		
			
		}
    
    
    }
    
    
    public double getBalance() {
    	return Balance;
    	
    }
    
    public void printTransactionHistory() {
    	System.out.println("/n *** Last Transaction History For " + AccountHolder + " _ ");
    	for(String Transaction: TransactionHistory) {
    		System.out.println(Transaction);		
    	}
       }
       }
	


