package BankAccountSimulation;

import java.util.Scanner;

public class SBIBankAccountSimulation {
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		
		System.out.print("Enter SBI Account Holder Name :->");
		String name = scanner.nextLine();
		
		System.out.print("Enter Initial Balance:-> ₹");
		double initialBalance = scanner.nextDouble();
		
		SBIAccount sbiAccount = new SBIAccount(name, initialBalance);
		
		while(true) {
			
			System.out.println("\n --- Bank Menu ---");
			System.out.println("1. Deposit");
			System.out.println("2. Withdraw");
			System.out.println("3. CheckBalance");
			System.out.println("4. Transaction History");
			System.out.println("5. Exit");
			System.out.println("Choose an option :->");
			
			int choice = scanner.nextInt();
			
			switch(choice) {
			case 1:
			System.out.print("Enter Deposit Amount :  ₹");
			double depositAmount = scanner.nextDouble();
			sbiAccount.Deposit(depositAmount);
			break;
			
			
			case 2:
				System.out.print("Enter Withdraw Amount :  ₹");
				double WithdrawAmmount = scanner.nextDouble();
				sbiAccount.Deposit(WithdrawAmmount);
				break;
				
			case 3:
		System.out.print("Current Balance : ₹" + sbiAccount.getBalance());
		     break;
		     
			case 4:
			sbiAccount.printTransactionHistory();
			break;
			
			case 5:
			System.out.println("Thank You For Using SBI Bank.We Are Greatful For Your Appreciation");
			scanner.close();
			return;
			
			default :
				System.out.println("You Choose Invalid Option.Try Again ");
			}
		}
	}

}
